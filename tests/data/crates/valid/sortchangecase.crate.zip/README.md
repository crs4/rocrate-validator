# Galaxy mini workflow

A tiny Galaxy workflow that sorts tabular lines according to the first column
and changes the text to upper case.
